package accadglidassignment;

import java.io.IOException;
import java.util.Scanner;

public class StringComparison {
	public static void main(String ...k)throws IOException
	{
		try
		{
			Boolean bisStringEqual = false;
			Scanner objScanner = new Scanner(System.in);
			System.out.println("Please enter first string");
			String strFirst = objScanner.nextLine();
			System.out.println("Please enter second string");
			String strSecond = objScanner.nextLine();
			if(strFirst.equalsIgnoreCase(strSecond))
			{
				bisStringEqual = true;
				if(strFirst.equals(strSecond))
				{
					System.out.println("Strings are equal in all aspects---" + bisStringEqual);
				}
				else
				{
					System.out.println("Strings are equal but have different cases---" + bisStringEqual);
				}
				
			}
			else
			{
				bisStringEqual = false;
				System.out.println("Strings are unequal---" + bisStringEqual);
			}
			objScanner.close();
		}
		catch(Exception e)
		{
			
		}
	}

}
